package ar.unlam.intraconsulta;

public enum Calificacion {
	DESAPROBADO, APROBADO, PROMOCIONA, FINAL, RECURSA
}
