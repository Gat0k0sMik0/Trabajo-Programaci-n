package ar.unlam.intraconsulta;

public enum Periodos {
	PRIMER_CUATRIMESTRE, SEGUNDO_CUATRIMESTRE
}
